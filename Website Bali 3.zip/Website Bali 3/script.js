document.addEventListener('DOMContentLoaded', () => {
    
    console.log('Swiper loaded:', typeof Swiper !== 'undefined');
    console.log('Element found:', document.querySelector('.testimonial-swiper'));
    // ============================
    // 1. INITIALIZE AOS
    // ============================
    AOS.init({
        once: true,
        offset: 50,
        duration: 800,
        easing: 'ease-out-cubic',
    });

    // ============================
    // 2. INITIALIZE SWIPER (Testimonials)
    // ============================
    const testimonialSwiper = new Swiper('.testimonial-swiper', {
        slidesPerView: 1,
        spaceBetween: 20,
        loop: true,
        autoplay: { 
            delay: 4500, 
            disableOnInteraction: false 
        },
        pagination: { 
            el: '.swiper-pagination', 
            clickable: true 
        },
        effect: 'fade',
        speed: 800,
        fadeEffect: { crossFade: true }
    });

    // ============================
    // 3. NAVBAR SCROLL EFFECT
    // ============================
    const navBg = document.getElementById('nav-bg');
    if (navBg) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) {
                navBg.classList.add('scrolled');
            } else {
                navBg.classList.remove('scrolled');
            }
        });
    }

    // ============================
    // 4. LANGUAGE SWITCHER
    // ============================
    const langSwitchBtn = document.getElementById('lang-switch');
    const langIcon = document.getElementById('lang-icon');
    const htmlTag = document.documentElement;
    
    let currentLang = 'en';

    const translations = {
        en: {
            nav_home: "Home",
            nav_dest: "Destinations",
            nav_act: "Activities",
            nav_cars: "Transport",
            nav_contact: "Contact",
            btn_book: "Book Now",
            hero_sub: "Premium Bali Experience",
            hero_title_1: "Luxury Bali",
            hero_title_2: "Journey",
            hero_desc: "Private tours led by Arabic-speaking drivers, luxury transport, and bespoke tropical experiences crafted exclusively for our Arab guests.",
            btn_explore: "Explore Tours",
            btn_whatsapp: "WhatsApp Us",
            sec_dest_sub: "The Paradise",
            sec_dest_title: "Exclusive Destinations",
            sec_act_sub: "Experience More",
            sec_act_title: "Curated Activities",
            sec_car_sub: "Comfort & Style",
            sec_car_title: "Premium Fleet",
            sec_prog_title: "Tour Programs",
            sec_contact_sub: "Get in Touch",
            footer_copy: "© 2026 AlFauzan Bali Tour. All Rights Reserved.",
            test_1: "The most professional service we've had in Bali. The driver was punctual, the car was spotless, and the itinerary was perfectly tailored to our needs.",
            test_2: "We booked the Hiace for our family reunion. Everything went smoothly from booking to the end of the tour. Truly premium.",
            test_3: "A truly luxurious experience. The driver was highly professional and the car was very comfortable. Highly recommended.",
            test_4: "Amazing experience! The VW tour was so much fun and our driver knew all the best spots. Highly recommend!",
            test_5: "Excellent service and professional driver. The car was very clean and the trip was extremely comfortable. Thank you team!",
            test_6: "Excellent service for our family trip to Ubud and Nusa Penida. The driver was very patient and helpful. Highly recommended!"
        },
        ar: {
            nav_home: "الرئيسية",
            nav_dest: "الوجهات",
            nav_act: "الأنشطة",
            nav_cars: "النقل",
            nav_contact: "اتصل بنا",
            btn_book: "احجز الآن",
            hero_sub: "تجربة بالي الفاخرة",
            hero_title_1: "رحلة",
            hero_title_2: "بالي الاستثنائية",
            hero_desc: "جولات خاصة مع سائقين يتحدثون العربية، وسائل نقل فاخرة، وذكريات استوائية لا تُنسى مُصممة خصيصاً للضيوف العرب.",
            btn_explore: "استكشف الجولات",
            btn_whatsapp: "راسلنا واتساب",
            sec_dest_sub: "الجنة",
            sec_dest_title: "وجهات حصرية",
            sec_act_sub: "المزيد من التجارب",
            sec_act_title: "أنشطة مختارة",
            sec_car_sub: "راحة وأناقة",
            sec_car_title: "أسطول السيارات",
            sec_prog_title: "برامج الجولات",
            sec_contact_sub: "تواصل معنا",
            footer_copy: "جميع الحقوق محفوظة © 2026 الفوزان بالي تور",
            test_1: "أفضل خدمة حجزناها في بالي. السائق دقيق في المواعيد، السيارة نظيفة تماماً، والبرنامج مصمم خصيصاً لاحتياجاتنا.",
            test_2: "استأجرنا سيارة Hiace لم شمل العائلة. كل شيء سار بسلاسة من الحجز حتى نهاية الرحلة. فعلاً خدمة فاخرة.",
            test_3: "تجربة فاخرة بكل المقاييس. السائق محترف جداً والسيارة مريحة. أنصح الجميع بالتعامل مع الفوزان بالي تور.",
            test_4: "تجربة رائعة! جولة VW كانت ممتعة جداً وسائقنا يعرف أفضل الأماكن. أنصح به بشدة!",
            test_5: "خدمة ممتازة وسائق محترف. السيارة نظيفة جداً والرحلة كانت مريحة للغاية. شكراً للفريق!",
            test_6: "خدمة ممتازة لرحلتنا العائلية إلى أوبود ونوسا بينيدا. السائق كان صبوراً ومفيداً جداً. موصى به بشدة!"
        }
    };

    // Language Switch Event
    if (langSwitchBtn) {
        langSwitchBtn.addEventListener('click', () => {
            // Toggle language
            currentLang = currentLang === 'en' ? 'ar' : 'en';
            
            // Update HTML attributes
            htmlTag.setAttribute('lang', currentLang);
            htmlTag.setAttribute('dir', currentLang === 'ar' ? 'rtl' : 'ltr');
            
            // Update icon text
            if (langIcon) {
                langIcon.textContent = currentLang === 'en' ? 'AR' : 'EN';
            }
            
            // Update fonts
            if (currentLang === 'ar') {
                document.body.classList.remove('font-poppins');
                document.body.classList.add('font-cairo');
                document.querySelectorAll('.font-playfair').forEach(el => {
                    el.classList.remove('font-playfair');
                    el.classList.add('font-cairo');
                });
            } else {
                document.body.classList.remove('font-cairo');
                document.body.classList.add('font-poppins');
                document.querySelectorAll('.font-cairo').forEach(el => {
                    el.classList.remove('font-cairo');
                    el.classList.add('font-playfair');
                });
            }

            // Update text content
            document.querySelectorAll('[data-i18n]').forEach(element => {
                const key = element.getAttribute('data-i18n');
                if (translations[currentLang]?.[key]) {
                    element.textContent = translations[currentLang][key];
                }
            });

            // Refresh Swiper (tanpa ubah direction)
            if (testimonialSwiper) {
                testimonialSwiper.update();
                testimonialSwiper.slideToLoop(0);
            }
            
            // Refresh AOS
            AOS.refresh();
        });
    }
});